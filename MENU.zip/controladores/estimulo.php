<?php

$text= $_POST["txt_estrato"];

if($text<=3)

{

  echo $text='registrado con estimulo';

}else{

    if($text >3)

echo "registrado sin estimulo";

}


?>