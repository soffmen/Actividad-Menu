<?php

$number= $_POST["documento"];
$radio=$_POST["opcion"];


{

  echo $text="se ha matriculado a '$radio' '$number' ";

}


?>