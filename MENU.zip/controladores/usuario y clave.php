<?php
$text = $_POST["txt_usuario"];
$numero = $_POST["clave"];

if ($text == 'itfip' && $numero == '2024') {
    echo "inicio sesion correctamente";
} else {
    echo "inicio sesion incorrectamente";
}
?>